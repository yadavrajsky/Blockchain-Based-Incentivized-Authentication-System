import axios from 'axios';

export const registerApi = async credentials => {
const response = await axios.post('/api/v1/register', credentials);
alert(response)
return response;
};

export const loginApi = async credentials => {
const response = await axios.post('/api/v1/login', credentials);
return response;
};
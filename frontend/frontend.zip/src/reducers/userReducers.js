import {
  CLEAR_ERRORS,
  CLEAR_MESSAGES,
  FAIL_LOGIN,
  FAIL_LOGOUT,
  FAIL_REGISTRATION,
  REQUEST_LOGIN,
  REQUEST_LOGOUT,
  REQUEST_REGISTRATION,
  SUCCESS_LOGIN,
  SUCCESS_LOGOUT,
  SUCCESS_REGISTRATION,
} from "../constants/userConstants";

export const userReducer = (state = { user: {}, error: null, msg: null ,loading:false }, action) => {
  switch (action.type) {
    case REQUEST_REGISTRATION:
    case REQUEST_LOGIN:
    case REQUEST_LOGOUT:
      return {
        ...state,
        loading: true,
      };
    case SUCCESS_REGISTRATION:
    case SUCCESS_LOGIN:
      return {
        loading: false,
        user: action.payload.data,
        is_authenticated: true,
        msg: action.payload.msg
      };

    case SUCCESS_LOGOUT:
      return {
        loading: false,
        user: {},
        is_authenticated: false,
      };

    case FAIL_REGISTRATION:
    case FAIL_LOGIN:
    case FAIL_LOGOUT:
      return {
        loading: false,
        error: action.payload,
        is_authenticated: false,
      };

    case CLEAR_ERRORS:
      return {
        ...state,
        error: null,
      };
      case CLEAR_MESSAGES:
        return {
          ...state,
          msg: null,
        };
    default:
      return state;
  }
};

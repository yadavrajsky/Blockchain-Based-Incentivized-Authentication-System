import React, { useState } from "react";

const Home = () => {

  return (
    <div className="container mx-auto text-center min-h-screen">
      Next generation Auth System
    </div>
  );
};

export default Home;

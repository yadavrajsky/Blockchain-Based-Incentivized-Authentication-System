import axios from "axios";
import {
  CLEAR_ERRORS,
  FAIL_LOGIN,
  FAIL_LOGOUT,
  FAIL_REGISTRATION,
  REQUEST_LOGIN,
  REQUEST_LOGOUT,
  REQUEST_REGISTRATION,
  SUCCESS_LOGIN,
  SUCCESS_LOGOUT,
  SUCCESS_REGISTRATION,
} from "../constants/userConstants";

// register action 
export const userRegistration = (userData) => async (dispatch) => {
  try {
    dispatch({ type: REQUEST_REGISTRATION });
    const headers = { Accept: "application/json" };
    const { data } = await axios.post("/api/v1/register", userData, {headers});
    // console.log(data);
    dispatch({
      type: SUCCESS_REGISTRATION,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: FAIL_REGISTRATION,
      payload: error.response.data.error,
    });
  }
};

//login action
export const userLogin = (userData) => async (dispatch) => {
  try {
    dispatch({ type: REQUEST_LOGIN });
    const headers = { Accept: "application/json" };

    const { data } = await axios.post("/api/v1/login", userData, {headers});
    dispatch({
      type: SUCCESS_LOGIN,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: FAIL_LOGIN,
      payload: error.response.data.error,
    });
  }
};

//logout action
export const userLogout = () => async (dispatch) => {
  try {
    dispatch({ type: REQUEST_LOGOUT });
    const headers = { Accept: "application/json" };

    const { data } = await axios.post("/api/v1/logout", headers);
    dispatch({
      type: SUCCESS_LOGOUT,
      payload: data,
    });
    localStorage.removeItem('persist:root');

  } catch (error) {
    dispatch({
      type: FAIL_LOGOUT,
      payload: error.response.data.error,
    });
    localStorage.removeItem('persist:root');

  }
};
// clear error 
export const clearErrors = () => async (dispatch) => {
  try {
    dispatch({ type: CLEAR_ERRORS });
  } catch (error) {
    console.log(error);
  }
};
